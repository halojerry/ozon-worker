#!/usr/bin/env python3
"""Platform-aware native module loader.

Automatically loads the correct binary (.so/.pyd) for the current platform
from _native/{darwin,win32,linux}/ directory.
"""
from __future__ import annotations

import importlib
import importlib.util
import platform
import sys
from pathlib import Path

_NATIVE_DIR = Path(__file__).resolve().parent / "_native"

_PLATFORM_MAP = {
    "Darwin": "darwin",
    "Windows": "win32",
    "Linux": "linux",
}

# Cache for loaded modules
_loaded: dict[str, object] = {}


def load_native(module_name: str):
    """Load a native module from the platform-specific directory.

    Usage:
        from scripts.lib._loader import load_native
        config_store = load_native("config_store")
        config_store.get_store("my_store")
    """
    if module_name in _loaded:
        return _loaded[module_name]

    plat = _PLATFORM_MAP.get(platform.system(), platform.system().lower())
    plat_dir = _NATIVE_DIR / plat

    if not plat_dir.is_dir():
        raise ImportError(
            f"No native modules for platform '{plat}'. "
            f"Available: {[d.name for d in _NATIVE_DIR.iterdir() if d.is_dir()]}"
        )

    # Find the binary file
    py_ver = f"{sys.version_info.major}{sys.version_info.minor}"
    candidates = [
        f"{module_name}.cpython-{py_ver}-{platform.machine()}",
        f"{module_name}.cpython-{py_ver}",
        f"{module_name}",
    ]

    binary_file = None
    for candidate in candidates:
        for suffix in ['.so', '.pyd']:
            f = plat_dir / f"{candidate}{suffix}"
            if f.exists():
                binary_file = f
                break
        if binary_file:
            break

    if not binary_file:
        # Fallback: try to import as regular Python module
        try:
            mod = importlib.import_module(f"scripts.lib.{module_name}")
            _loaded[module_name] = mod
            return mod
        except ImportError:
            raise ImportError(
                f"Cannot find native module '{module_name}' for platform '{plat}' "
                f"in {plat_dir}"
            )

    # Load the binary module
    spec = importlib.util.spec_from_file_location(
        f"scripts.lib.{module_name}",
        str(binary_file),
    )
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot create spec for {binary_file}")

    mod = importlib.util.module_from_spec(spec)
    sys.modules[f"scripts.lib.{module_name}"] = mod
    spec.loader.exec_module(mod)
    _loaded[module_name] = mod
    return mod
