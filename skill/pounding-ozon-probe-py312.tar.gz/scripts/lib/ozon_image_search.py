#!/usr/bin/env python3
"""Auto-generated stub — loads native binary for current platform."""
import importlib.util as _ilu
import platform as _plat
import sys as _sys
import sysconfig
from pathlib import Path as _Path

_plat_name = {"Darwin": "darwin", "Windows": "win32", "Linux": "linux"}.get(
    _plat.system(), _plat.system().lower()
)
_native_dir = _Path(__file__).resolve().parent / "_native" / _plat_name
_ext_suffix = sysconfig.get_config_var("EXT_SUFFIX")
_binary = None
# Try exact EXT_SUFFIX first (e.g., .cpython-312-darwin.so)
_f = _native_dir / ("ozon_image_search" + _ext_suffix)
if _f.exists():
    _binary = _f
else:
    # Fallback: search for any matching file
    for _p in _native_dir.glob("ozon_image_search.*"):
        if _p.suffix in (".so", ".pyd"):
            _binary = _p
            break

if _binary:
    _spec = _ilu.spec_from_file_location(__name__, str(_binary))
    if _spec and _spec.loader:
        _mod = _ilu.module_from_spec(_spec)
        _spec.loader.exec_module(_mod)
        for _n in dir(_mod):
            if not _n.startswith("__"):
                globals()[_n] = getattr(_mod, _n)
else:
    raise ImportError(f"No native binary for ozon_image_search on {_plat_name}")
